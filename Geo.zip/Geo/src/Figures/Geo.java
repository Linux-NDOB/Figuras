
package Figures;

import javax.swing.JOptionPane;


public class Geo {
    
    public float lado;
    
    public float base;
    
    public float altura;

    public Geo() {
        lado = 0;
        base = 0;
        altura = 0;
    }


    public float getLado() {
        return lado;
    }

    public void setLado(float lado) {
        this.lado = lado;
    }

    public float getBase() {
        return base;
    }

    public void setBase(float base) {
        this.base = base;
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }
    
    // Cuadrado
    
    public void Carea(){
        
        float lado = Float.parseFloat(JOptionPane.showInputDialog("Ingrese el valor del lado"));
        
        float areat = lado * lado;
        
        JOptionPane.showMessageDialog(null, "El area del cuadrado es: " + areat);
        
        

        
    }
    
    public void Cperi(){
        
        float lado = Float.parseFloat(JOptionPane.showInputDialog("Ingrese el valor del lado"));
    
        float per = lado + lado + lado + lado;
        
        JOptionPane.showMessageDialog(null, "El perimetro del cuadrado es: " + per);
        
        
        
    }
    
    // Triangulo
    
   
    
    public void Tperi(){
        
        float base = Float.parseFloat(JOptionPane.showInputDialog("Ingrese el valor de la base"));
    
        float per = base+base+base;
        
        JOptionPane.showMessageDialog(null, "El perimetro del triangulo es: " + per);
        
        
        
    }
    
    // Rectangulo
    
    public void Rarea(){
        
        float base = Float.parseFloat(JOptionPane.showInputDialog("Ingrese el valor de la base"));
        
        float altura = Float.parseFloat(JOptionPane.showInputDialog("Ingrese el valor de la altura "));
        
        float areat = base * altura;
        
        JOptionPane.showMessageDialog(null, "El area del rectangulo es: " + areat);

        
    }
    
    public void Rperi(){
        
        float base = Float.parseFloat(JOptionPane.showInputDialog("Ingrese el valor de la base"));
        
        float altura = Float.parseFloat(JOptionPane.showInputDialog("Ingrese el valor de la altura "));
    
        float per = ((2*base)+(2*altura));
        
        //int a = Integer.parseInt(JOptionPane.showInputDialog("2"));
        
        JOptionPane.showMessageDialog(null, "El perimetro del rectangulo es: " + per);
        
        
        
    }
    
    
}
